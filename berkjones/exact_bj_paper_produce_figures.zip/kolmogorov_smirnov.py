"""This module contains the Kolmogorov-Smirnov goodness-of-fit test.
The basic KS test as well as the Dn+ and Dn- tests are implemented, these tests are identical to
Kn+ and Kn- but without the sqrt(n).

Reference: Art of Computer Programming, Knuth Vol. 2, chapter 3.3.1 B
"""
from numpy import arange, argmax, sort, asarray
import common

def kstest_slow(samples, F = common.uniform_01_cdf):
    """Calculates the Kolmogorov Smirnov test between a collection of samples
    and a known distribution (given by its Cumulative Distribution Function F):
        D_n = max |F_n(x) - F(x)|

    Where F_n is the empirical CDF of the samples x_1, ..., x_n: F_n(x) = 1/n  \sum_i I(x_i <= x)

    samples - a sequence of real numbers
    F -  The CDF of the distribution that might have generated the samples. This should be a a monotone increasing function from R to [0,1] given as a python function.
    return value: A number between 0 and 1. Higher values mean worse fit between the samples and the distribution. Under the null hypothesis the distribution of return values is known, therefore a p-value can be calculated.
    """
    n = float(len(samples))
    distances = []
    for x in samples:
        num_samples_below_x = len([y for y in samples if y<x])
        # F_n is composed of n discrete steps, we are interested in the values to the left and right of each step.
        # i.e. at F_n(x-epsilon) and F_n(x+epsilon)
        F_n_at_x_left = num_samples_below_x / n
        F_n_at_x_right = (num_samples_below_x+1) / n
        distances.append(abs(F_n_at_x_left - F(x)))
        distances.append(abs(F_n_at_x_right - F(x)))
    #print distances
    return (n**0.5)*max(distances)

def kstest_slow_argmax(samples, F = common.uniform_01_cdf):
    """Calculates the Kolmogorov Smirnov test between a collection of samples
    and a known distribution (given by its Cumulative Distribution Function F):
        D_n = max |F_n(x) - F(x)|

    Where F_n is the empirical CDF of the samples x_1, ..., x_n: F_n(x) = 1/n  \sum_i I(x_i <= x)

    samples - a sequence of real numbers
    F -  The CDF of the distribution that might have generated the samples. This should be a a monotone increasing function from R to [0,1] given as a python function.
    return value: A number between 0 and 1. Higher values mean worse fit between the samples and the distribution. Under the null hypothesis the distribution of return values is known, therefore a p-value can be calculated.
    """
    n = float(len(samples))
    distances = []
    for x in samples:
        num_samples_below_x = len([y for y in samples if y<x])
        # F_n is composed of n discrete steps, we are interested in the values to the left and right of each step.
        # i.e. at F_n(x-epsilon) and F_n(x+epsilon)
        F_n_at_x_left = num_samples_below_x / n
        F_n_at_x_right = (num_samples_below_x+1) / n
        #print 'F(x):', F(x)
        #print 'F_n_left(x):', F_n_at_x_left
        #print 'F_n_right(x):', F_n_at_x_right
        distances.append(abs(F_n_at_x_left - F(x)))
        distances.append(abs(F_n_at_x_right - F(x)))
    #print distances
    return argmax(distances) / 2

def _Dn_minus(sorted_samples_01):
    """This is a Kolmogorov-Smirnov test measures only when the sorted samples are surprisingly smaller than they should be"""
    n = float(len(sorted_samples_01))
    return max(F_x_i - i/n for (i, F_x_i) in enumerate(sorted_samples_01))

def _Dn_plus(sorted_samples_01):
    n = float(len(sorted_samples_01))
    return max((i+1)/n - F_x_i for (i, F_x_i) in enumerate(sorted_samples_01))

def kstest(sorted_F_at_samples):
    """Calculates the Kolmogorov Smirnov test between a collection of samples and a known distribution (given by its CDF)

    max |F_n(x) - F(x)|

    Where F_n is the empirical CDF of the samples {x_1, ..., x_n}:
        F_n(x) = 1/n  \sum_i I(x_i <= x)
    """
    #sorted_F_at_samples = sort(F(asarray(samples)))
    assert sorted_F_at_samples[0] >= 0
    assert sorted_F_at_samples[-1] <= 1
    n = len(sorted_F_at_samples)
    return (n**0.5) * max(_Dn_minus(sorted_F_at_samples), _Dn_plus(sorted_F_at_samples))

def kstest_fast(sorted_F_at_samples):
    """Like kstest, but assumes uniform_01_cdf and sorted samples"""
    assert sorted_F_at_samples[0] >= 0
    assert sorted_F_at_samples[-1] <= 1
    n = float(len(sorted_F_at_samples))
    Dn_minus = (sorted_F_at_samples - arange(0, 1 - 1/(2*n), 1/n)).max()
    Dn_plus = (arange(1/n, 1 + 1/(2*n), 1/n)- sorted_F_at_samples).max()
    return (n**0.5)*max(Dn_minus, Dn_plus)

def kstest_approximate(samples, F = common.uniform_01_cdf):
    """Calculates a quick and common approximation to the Kolmogorov Smirnov test between a collection of samples and a known distribution (given by its CDF)
    """
    sorted_F_at_samples = [F(x) for x in sorted(samples)]
    n = float(len(sorted_F_at_samples))
    return max(abs(F_x_i - i/n) for (i, F_x_i) in enumerate(sorted_F_at_samples))

class KSPValueEstimator(common.PValueEstimator):
    def uniform_01_fit_test_function(self, samples):
        return kstest(samples)
