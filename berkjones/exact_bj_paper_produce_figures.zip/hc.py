import os
from itertools import izip
import math
import numpy
from numpy import arange, array, ones, zeros, hstack, vstack, matrix, diag, identity, dot, log, absolute, argsort, sign, sqrt, maximum, minimum
from numpy.random import normal
from numpy.polynomial import Polynomial
from random import normalvariate, random
import scipy
import scipy.stats
from scipy.special import gammaln
import pylab
from pylab import plot, figure, legend, title, xlabel, ylabel, close, draw, grid, xticks, yticks, xlim, ylim
import matplotlib
from matplotlib.colors import ListedColormap, NoNorm
from utils import all_equal, is_sorted, beep, mean
#import speed
#from filecache import filecache
import socket
import time
#from bigfloat import BigFloat, precision
from dirs import CKS_DIR
import common


def uniform_prob_cdf(i, n, t):
    """Calculates the probability that the i-th smallest element (when counting from 0 !!) out of n uniform[0,1] variables is smaller than t. This function works for scalars as well as numpy arrays"""
    # betainc(k, n-k+1, t) = gamma(n+1) / (gamma(k)*gamma(n-k+1)) * integral
    # = (n! / (k-1)!(n-k)!) * integral(x**(k-1) (1-x)**(n-k), t=0..t)
    #
    # We want to calculate (n-1)! / ((k-1)!(n-k)!) * integral..
    return scipy.special.betainc(i+1, n-i, t)

def uniform_prob_cdf_inv(i, n, t):
    return scipy.special.betaincinv(i+1, n-i, t)

def _hc_init(sorted_uniform01_data, alpha0, input_runtime_checks):
    (N,) = sorted_uniform01_data.shape
    if alpha0 < 1:
        n = int(N*alpha0)
    else:
        n = N-1
    if input_runtime_checks:
        assert all(sorted_uniform01_data == sorted(sorted_uniform01_data))
        assert 0 <= sorted_uniform01_data[0] 
        assert sorted_uniform01_data[-1] <= 1
    data = sorted_uniform01_data[:n]
    return (N, n, data)

def hc2004(sorted_uniform01_data, alpha0, input_runtime_checks = False):
    """This function is an implementation of the Higher Criticism statistic.
    See: "Higher Criticism for Detecting Sparse Heterogeneous Mixtures" by David Donoho and Jiashun Jin, page 966.

    The statistic is meant to be a good classifier to differnetiate between two cases:
    H_0: The data is all Uniform[0,1]
    N_1: Most of the data is Uniform[0,1], a small subset is distributed differently

    supposedly_uniform01_data - list of double numbers, in the range [0,1]. For testing goodness of fit
        against a standard normal model, one must call sorted_p_values() on the data beforehand.
    alpha0 - the largest expected fraction of non-standard-normal data
    """
    (N, n, data) = _hc_init(sorted_uniform01_data, alpha0, input_runtime_checks)
    # Actually this seems to be a bug in HC, the actual expected value is arange(1, n+1) / float(N+1)
    expected_values = arange(1, n+1) / float(N)
    diffs_from_expectation = expected_values - data
    normalized_deviations = (N**0.5) * numpy.absolute(expected_values-data) / numpy.sqrt(data*(1-data))
    max_i = normalized_deviations.argmax()
    return (normalized_deviations[max_i], max_i)

class HC2004PvalueEstimator(common.PValueEstimator):
    def uniform_01_fit_test_function(self, samples):
        return hc2004(samples, 1.0)[0]

def hc2008(sorted_uniform01_data, alpha0, input_runtime_checks = False):
    """A tiny variation on hc2004, this appeared in Donoho&Jin's PNAS paper:
    Higher Criticism Thresholding: Optimal feature selection when useful features are rare and weak
    """
    (N, n, data) = _hc_init(sorted_uniform01_data, alpha0, input_runtime_checks)
    # Actually this seems to be a bug in HC, the actual expected value is arange(1, n+1) / float(N+1)
    expected_values = arange(1, n+1) / float(N)
    diffs_from_expectation = expected_values - data
    normalized_deviations = (N**0.5) * numpy.absolute(expected_values-data) / numpy.sqrt(expected_values*(1-expected_values))
    max_i = normalized_deviations.argmax()
    return (normalized_deviations[max_i], max_i)

class HC2008PvalueEstimator(common.PValueEstimator):
    def uniform_01_fit_test_function(self, samples):
        return hc2008(samples, 1.0)[0]

def hcbeta(sorted_uniform01_data, alpha0):
    (N,) = sorted_uniform01_data.shape
    n = int(alpha0*N)
    #print 'p_{(i)}:', sorted_uniform01_data
    order_statistic_p_values = uniform_prob_cdf(arange(n), N, sorted_uniform01_data[:n])
    #print 'pvalue(p_{(i)}):', order_statistic_p_values
    min_i = numpy.argmin(order_statistic_p_values)
    return (-order_statistic_p_values[min_i], min_i)

def _hcbeta_two_sided(sorted_uniform01_data):
    (N,) = sorted_uniform01_data.shape
    order_statistic_p_values = uniform_prob_cdf(arange(N), N, sorted_uniform01_data[:N])
    min_i_lower = numpy.argmin(order_statistic_p_values)
    min_i_upper = numpy.argmax(order_statistic_p_values)
    return (max(1-order_statistic_p_values[min_i_lower], order_statistic_p_values[min_i_upper]), min_i_lower, min_i_upper)

def hcbeta_two_sided(sorted_uniform01_data):
    return _hcbeta_two_sided(sorted_uniform01_data)[0]

def hcbeta_one_sided(sorted_uniform01_data, alpha = 1.0):
    return 1 + hcbeta(sorted_uniform01_data, alpha)[0]

class HCBetaPvalueEstimator(common.PValueEstimator):
    def uniform_01_fit_test_function(self, samples):
        return hcbeta(samples, 1.0)[0]


#### Tests ###################################################################

#import pytest

EPS = 0.000001
def arrays_are_close(arr0, arr1):
    return (numpy.absolute(arr0-arr1) < EPS).all()

def test_stdnormal_p_value():
    assert stdnormal_p_value(0) == 1.0
    assert 0.317310507-EPS < stdnormal_p_value(1) < 0.317310507+EPS
    assert 0.045500263896-EPS < stdnormal_p_value(2) < 0.045500263896+EPS
    assert all(stdnormal_p_value([1,2]) < [0.317310507+EPS, 0.045500263896+EPS])
    assert all(stdnormal_p_value([1,2]) > [0.317310507-EPS, 0.045500263896-EPS])

def test_uniform_prob_cdf():
    assert uniform_prob_cdf(0, 1, 0.123) == 0.123
    assert uniform_prob_cdf(1, 2, 0.123) == 0.123**2
    assert uniform_prob_cdf(999, 1000, 0.1) < 0.000000000001
    assert uniform_prob_cdf(20, 40, 0) == 0
    assert uniform_prob_cdf(20, 40, 1) == 1

def test_hc2008_and_hc_2004():
    data = array([0.04550026, 0.31731051, 1])
    expected_vals = [0.3333333333333, 0.66666666666]
    diffs_from_expectation = expected_vals - data[:2]

    hc_2004_normalization = [(3 / (0.04550026*(1-0.04550026)))**0.5, (3 / (0.31731051*(1-0.31731051)))**0.5]
    hc_2008_normalization = (3 / (0.3333333333333333*0.6666666666666))**0.5

    normalized_2004 = hc_2004_normalization * (diffs_from_expectation)
    normalized_2008 = hc_2008_normalization * (diffs_from_expectation)

    (max_val_2008, max_i_2008) = hc2008(data, 0.7)
    assert normalized_2008.argmax() == max_i_2008
    assert max_val_2008-EPS < normalized_2008.max() < max_val_2008+EPS

    (max_val_2004, max_i_2004) = hc2004(data, 0.7)
    assert normalized_2004.argmax() == max_i_2004
    assert max_val_2004-EPS < normalized_2004.max() < max_val_2004+EPS

