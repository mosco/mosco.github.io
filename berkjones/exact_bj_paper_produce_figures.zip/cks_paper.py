import sys
import time
from multiprocessing import Pool, cpu_count
from itertools import repeat
import numpy
from numpy import arange, sort, array, asarray, zeros, sqrt, pi, log, exp, power, dstack
from pylab import plot, legend, xlabel, ylabel, title, grid, subplots_adjust, xticks, yticks, meshgrid, xlim, ylim, pcolor, colorbar, figure, text, gca
from matplotlib.colors import ListedColormap
import scipy.stats


#blah blah!!

import roc
from common import save_data, load_data, save_figure, save_figure_for_publication_bigfonts, save_figure_for_publication_smallfonts
import kolmogorov_smirnov
import anderson_darling
from hc import hc2004, hc2008
import berk_jones
import cks

RARE_WEAK_MAX_EPSILON = 0.5 
ALPHA_FOR_RAREWEAK_SWEEP = 0.05
PLOT_STYLE_KS = 'r-'
PLOT_STYLE_AD = 'g--'
PLOT_STYLE_CKS = 'bd-'
MARKERSIZE = 12

def parallel_map(func, seq):
    if sys.platform == 'win32':
        # The multiprocessing.Pool doesn't work properly on windows
        # since there is no fork() command.
        return map(func, seq)
    else:
        # Number of real CPUs is typically half of reported
        # (due to hyperthreading).
        N_CPUS = cpu_count()/2
        pool = Pool(N_CPUS)
        return pool.map(func, seq)

###############################################################################
#### Power for detection shifted and scaled Normal distribution ###############
###############################################################################

class TransformedIIDNormalGenerator(object):
    """Generate sorted tuples of phi-transformed Normal(mu, sigma) tuples.
    These samples are transformed by the N(0,1) CDF.
    """
    def __init__(self, mu, sigma, n):
        self._mu = mu
        self._sigma = sigma
        self._n = n
    def next(self):
        normal_data = numpy.random.normal(loc = self._mu, scale = self._sigma, size = self._n)
        pvalues = scipy.stats.zprob(normal_data)
        return sort(pvalues)

def KS_vs_AD_vs_CKS_gaussian((reps, n, mu, sigma, alpha)):
    H0_generator = TransformedIIDNormalGenerator(0, 1, n)
    H1_generator = TransformedIIDNormalGenerator(mu, sigma, n)
    test_statistics = [
            kolmogorov_smirnov.kstest_fast,
            anderson_darling.anderson_darling_test,
            lambda xs: 1-cks.cks_fast(xs),
    ]
    rocgen = roc.ROCGeneratorMulti(test_statistics, ['KS', 'AD', 'CKS'], H0_generator, H1_generator)
    rocgen.generate(reps)
    return tuple([rocgen.roc_curves[i].get_power_at_alpha(alpha) for i in range(3)])

def KS_vs_AD_vs_CKS_gaussian_parallelized(reps, n, mu_list, sigma_list, alpha):
    results = parallel_map(KS_vs_AD_vs_CKS_gaussian, zip(repeat(reps), repeat(n), mu_list, sigma_list, repeat(alpha)))
    (KS_power, AD_power, CKS_power) = zip(*results)
    return (KS_power, AD_power, CKS_power)

def precalc_normal_displacement_KS_vs_AD_vs_CKS(reps):
    N = 100
    MU_LIST = arange(0, 0.6, 0.05)
    SIGMA_LIST = [1]*len(MU_LIST)
    ALPHA = 0.01
    (KS_power, AD_power, CKS_power) = KS_vs_AD_vs_CKS_gaussian_parallelized(reps, N, MU_LIST, SIGMA_LIST, ALPHA)
    save_data('precalc_normal_displacement_KS_vs_AD_vs_CKS_n100', mu_list=MU_LIST, ks_power=KS_power, ad_power=AD_power, cks_power=CKS_power)

@save_figure_for_publication_bigfonts('normal_displacement_ks_vs_ad_vs_cks_n100')
def figure_normal_displacement_KS_vs_AD_vs_CKS():
    data = load_data('precalc_normal_displacement_KS_vs_AD_vs_CKS_n100')
    plot(data.mu_list, data.ks_power, PLOT_STYLE_KS, label='KS', markersize=MARKERSIZE)
    plot(data.mu_list, data.ad_power, PLOT_STYLE_AD, label='AD', markersize=MARKERSIZE)
    plot(data.mu_list, data.cks_power, PLOT_STYLE_CKS, label='CKS', markersize=MARKERSIZE)
    legend(loc='lower right')
    xlabel('$\mu$')
    ylabel(r'Power at $\alpha = 1\% $')
    title('$H_0$: $\mathcal{N}(0,1)$ vs. $H_1$: $\mathcal{N}(\mu,1)$').set_y(1.01)
    grid(True)
    
def precalc_normal_scaling_KS_vs_AD_vs_CKS(reps):
    N = 100
    SIGMA_LIST = arange(0.50, 2, 0.05)
    MU_LIST = [0]*len(SIGMA_LIST)
    ALPHA = 0.01
    (KS_power, AD_power, CKS_power) = KS_vs_AD_vs_CKS_gaussian_parallelized(reps, N, MU_LIST, SIGMA_LIST, ALPHA)
    save_data('precalc_normal_scaling_KS_vs_AD_vs_CKS_n100', sigma_list=SIGMA_LIST, ks_power=KS_power, ad_power=AD_power, cks_power=CKS_power)

@save_figure_for_publication_bigfonts('normal_scaling_ks_vs_ad_vs_cks_n100')
def figure_normal_scaling_KS_vs_AD_vs_CKS():
    data = load_data('precalc_normal_scaling_KS_vs_AD_vs_CKS_n100')
    plot(data.sigma_list, data.ks_power, PLOT_STYLE_KS, label='KS')
    plot(data.sigma_list, data.ad_power, PLOT_STYLE_AD, label='AD')
    plot(data.sigma_list, data.cks_power, PLOT_STYLE_CKS, label='CKS')
    legend(loc='lower right')
    xlabel('$\sigma$')
    ylabel(r'Power at $\alpha = 1\% $')
    title('$H_0$: $\mathcal{N}(0,1)$ vs. $H_1$: $\mathcal{N}(0,\sigma^2)$').set_y(1.01)
    grid(True)

###############################################################################
#### Detection of deviations from power law ###################################
###############################################################################

class PowerlawDistribution(object):
    """Represents a powerlaw distribution with density proportional to x^(-alpha) for any x>=xmin.

    Normalization constraints determine that above xmin the PDF is:
        f(x) = (a-1)/xmin (x/xmin)^(-a)

    The CDF is:
        F(x) = 1 - (x/xmin)^(-a+1)
    """
    def __init__(self, xmin, alpha):
        self.xmin = xmin
        self.alpha = alpha
        self.name = 'Powerlaw'

    def __repr__(self):
        return 'PowerlawDistribution(xmin = %f, alpha = %f)' % (self.xmin, self.alpha)

    def generate(self, n):
        uniform_samples = numpy.random.random(n)
        xmin = self.xmin
        a = self.alpha
        return xmin*power(1-uniform_samples, -1./(a-1))

    def cdf(self, xs):
        xs = asarray(xs)
        tail_mask = (xs >= self.xmin)
        cdf = zeros(len(xs))
        cdf[tail_mask] = 1 - power(xs[tail_mask]/self.xmin, -self.alpha+1)
        return cdf

    def pdf(self, xs):
        xs = asarray(xs)
        ys = zeros(xs.shape)
        mask = xs >= self.xmin
        ys[mask] = ((self.alpha-1) / self.xmin) * (xs[mask]/self.xmin)**(-self.alpha)
        return ys

class ExponentialDistribution(object):
    def __init__(self, xmin, lambda_):
        self.xmin = xmin
        self.lambda_ = lambda_
        self.name = 'Exponential'

    def generate(self, n):
        rs = numpy.random.random(n)
        xs = self.xmin - (1.0/self.lambda_) * numpy.log(1-rs)
        return xs

    def pdf(self, xs):
        xs = asarray(xs)
        lam = self.lambda_
        xmin = self.xmin
        ys = zeros(xs.shape)
        mask = xs >= self.xmin
        ys[mask] = lam * exp(lam*xmin) * exp(-lam*xs[mask])
        return ys

class LognormalDistribution(object):
    def __init__(self, xmin, mu, sigma):
        self.mu = mu
        self.sigma = sigma
        self.xmin = xmin
        self.name = 'Lognormal'

    def generate(self, n):
        res = []
        while len(res) < n:
            before_cutoff = numpy.random.lognormal(self.mu, self.sigma, n)
            res.extend(before_cutoff[before_cutoff > self.xmin])
        xs = array(res[:n])
        return xs

    def pdf(self, xs):
        xs = asarray(xs)
        xmin = self.xmin
        mu = self.mu
        sigma = self.sigma
        ys = zeros(xs.shape)
        mask = xs >= self.xmin
        const = (sqrt(2.0/pi)/sigma) / scipy.special.erfc((log(xmin)-mu)/(sqrt(2)*sigma))
        ys[mask] = (const / xs[mask]) * exp(-((log(xs[mask])-mu)**2 / (2*sigma**2.0)))
        return ys

# Definitions related to figure 4.1.b of Clauset, Shalizi, Newman, 2009
FIG41B_NRANGE = [int(10**(1.0+0.075*i)) for i in range(41)]
FIG41B_POWERLAW = PowerlawDistribution(15, 2.5)
FIG41B_EXPONENTIAL = ExponentialDistribution(15, 0.125)
FIG41B_LOGNORMAL = LognormalDistribution(15, 0.3, 2)

@save_figure_for_publication_smallfonts('powerlaw_vs_exponential_vs_lognormal_pdf')
def figure_powerlaw_vs_exponential_vs_lognormal_pdf():
    xs = arange(15,90,0.01)
    xticks(arange(15,90,10))
    plot(xs, FIG41B_POWERLAW.pdf(xs), 'b--', label = '$f(x) \propto x^{-2.5}$', linewidth=2)
    plot(xs, FIG41B_LOGNORMAL.pdf(xs), 'r:', label = '$\log X \sim \mathcal{N}(0.3, 2^2)$', linewidth=2)
    plot(xs, FIG41B_EXPONENTIAL.pdf(xs), 'k', label = '$f(x) \propto e^{-x/8}$', linewidth=2)
    xlabel('$x$')
    ylabel('$f(x)$')
    grid(True)
    legend()

TWO_SIDED_TEST_STATISTICS = [
    kolmogorov_smirnov.kstest_fast,
    anderson_darling.anderson_darling_test,
    lambda xs: 1-cks.cks_fast(xs),
]
TWO_SIDED_TEST_STATISTICS_NAMES = [
    'KS',
    'AD',
    'CKS',
]

def generate_generator(f):
    while True:
        yield f()

def detection_powerlaw_vs_alternative(H0_distribution, H1_distribution, reps, n_range, alpha):
    computed_statistic_powers = [[] for t in TWO_SIDED_TEST_STATISTICS_NAMES]
    for n in n_range:
        print 'n:', n
        H0_generator = generate_generator(lambda: sort(H0_distribution.cdf(H0_distribution.generate(n))))
        H1_generator = generate_generator(lambda: sort(H0_distribution.cdf(H1_distribution.generate(n))))
        rocgen = roc.ROCGeneratorMulti(TWO_SIDED_TEST_STATISTICS, TWO_SIDED_TEST_STATISTICS_NAMES, H0_generator, H1_generator)
        rocgen.generate(reps)
        for (powers, roc_curve) in zip(computed_statistic_powers, rocgen.roc_curves):
            powers.append(roc_curve.get_power_at_alpha(alpha))
    return computed_statistic_powers

def precalc_powerlaw_vs_lognormal_detection(reps):
    N_RANGE = arange(10,161,10)
    ALPHA = 0.01
    powers = detection_powerlaw_vs_alternative(FIG41B_POWERLAW, FIG41B_LOGNORMAL, reps, N_RANGE, ALPHA)
    save_data('precalc_powerlaw_vs_lognormal_detection', n_range=N_RANGE, alpha=ALPHA, powers=powers)

def precalc_powerlaw_vs_exponential_detection(reps):
    N_RANGE = arange(5,101,5)
    ALPHA = 0.01
    powers = detection_powerlaw_vs_alternative(FIG41B_POWERLAW, FIG41B_EXPONENTIAL, reps, N_RANGE, ALPHA)
    save_data('precalc_powerlaw_vs_exponential_detection', n_range=N_RANGE, alpha=ALPHA, powers=powers)

@save_figure_for_publication_bigfonts('powerlaw_vs_exponential_detection_power')
def figure_powerlaw_vs_exponential_detection_power():
    data = load_data('precalc_powerlaw_vs_exponential_detection')
    (ks_power, ad_power, cks_power) = tuple(data.powers)
    plot(data.n_range, ks_power, PLOT_STYLE_KS, label = 'KS')
    plot(data.n_range, ad_power, PLOT_STYLE_AD, label = 'AD')
    plot(data.n_range, cks_power, PLOT_STYLE_CKS, label = 'CKS')
    xticks(arange(0,101,10))
    yticks(arange(0,1.01,0.2))
    xlabel('n')
    ylabel('Power')
    grid(True)
    legend(loc='lower right')

@save_figure_for_publication_bigfonts('powerlaw_vs_lognormal_detection_power')
def figure_powerlaw_vs_lognormal_detection_power():
    data = load_data('precalc_powerlaw_vs_lognormal_detection')
    (ks_power, ad_power, cks_power) = tuple(data.powers)
    plot(data.n_range, ks_power, PLOT_STYLE_KS, label = 'KS')
    plot(data.n_range, ad_power, PLOT_STYLE_AD, label = 'AD')
    plot(data.n_range, cks_power, PLOT_STYLE_CKS, label = 'CKS')
    xticks(arange(10,161,20))
    yticks(arange(0,1.01,0.2))
    xlabel('n')
    ylabel('Power')
    grid(True)
    legend(loc='lower right')

###############################################################################
#### Rare weak detection                    ###################################
###############################################################################

class UniformGoodnessOfFitStatistic(object):
    def __init__(self, calcfunc, name, plotstyle, plotcolor, epsilon, mu):
        self.name = name
        self.calcfunc = calcfunc
        self.plotstyle = plotstyle
        self.plotcolor = plotcolor
        self.epsilon = epsilon
        self.mu = mu

    def __call__(self, supposedly_uniform_data, processed_data):
        result = self.calcfunc(supposedly_uniform_data, self.epsilon, self.mu, processed_data = processed_data)
	assert not hasattr(result, '__len__')
	return result

def sorted_p_values(data, H0_p_value_func):
    (N,) = data.shape
    p_values = H0_p_value_func(data)
    assert 0 <= p_values.min() <= p_values.max() <= 1
    p_values.sort()
    return p_values

def stdnormal_p_value_one_sided(data):
    """Calculate the probability of a standard normal variable to be larger than the data samples:
        P(X > data)    where    X ~ N(0,1)

        data: number or numpy array of real numbers
        return value: p-value or numpy array of p-values in the range (0,1)
    """
    return 1-scipy.stats.zprob(data)

def hc2004_statistic(data, epsilon, mu, processed_data):
    assert epsilon < 0.5
    return hc2004(processed_data, RARE_WEAK_MAX_EPSILON, False)[0]

def hc2008_statistic(data, epsilon, mu, processed_data):
    assert epsilon < 0.5
    return hc2008(processed_data, RARE_WEAK_MAX_EPSILON, False)[0]

def cks_statistic(data, epsilon, mu, processed_data):
    assert epsilon < 0.5
    # Note that CKS gives low scores to significant results, unlike all the other statistics.
    # So we return 1.0-CKS, so that all statistics are compatible in the sense of "larger is more significant".
    return 1.0 - cks.cks_plus(processed_data, RARE_WEAK_MAX_EPSILON)

def likelihood_ratio_statistic(data, epsilon, mu, processed_data):
    assert 0 <= epsilon <= 1
    norm_null = scipy.stats.norm(loc = 0, size = 1)
    norm_pos = scipy.stats.norm(loc = mu, size = 1)
    norm_null_pdf = norm_null.pdf(data)
    log_likelihood_null = numpy.log(norm_null_pdf).sum()
    log_likelihood_mixture = numpy.log((1-epsilon)*norm_null_pdf + epsilon*norm_pos.pdf(data)).sum()
    return log_likelihood_mixture - log_likelihood_null

def max_statistic(data, epsilon, mu, processed_data):
    return numpy.max(numpy.array(data))

def sum_statistic(data, epsilon, mu, processed_data):
    return numpy.array(data).sum()

def bj_statistic(data, epsilon, mu, processed_data):
    assert epsilon < 0.5
    return berk_jones.bjtest(processed_data, 0.5)

STATISTIC_DICT = {
        'optimal':
            lambda epsilon, mu:
                UniformGoodnessOfFitStatistic(likelihood_ratio_statistic, 'Optimal', None, 'r', epsilon, mu),
        'hc2004':
            lambda epsilon, mu:
                UniformGoodnessOfFitStatistic(hc2004_statistic, r'$\mbox{HC}^{2004}$', '*', 'g', epsilon, mu),
        'hc2008':
            lambda epsilon, mu:
                UniformGoodnessOfFitStatistic(hc2008_statistic, r'$\mbox{HC}^{2008}$', 'o', 'k', epsilon, mu),
        'cksplus':
            lambda epsilon, mu:
                UniformGoodnessOfFitStatistic(cks_statistic, r'$\mbox{CKS}^{+}$', 'D', 'b', epsilon, mu),
        'max(x)':
            lambda epsilon, mu:
                UniformGoodnessOfFitStatistic(max_statistic, r'$ \max x_i $', 'x', 'c', epsilon, mu),
        'sum(x)':
            lambda epsilon, mu:
                UniformGoodnessOfFitStatistic(sum_statistic, r'$ \sum x_i $', '<', 'c', epsilon, mu),

        'bj':
            lambda epsilon, mu:
                UniformGoodnessOfFitStatistic(bj_statistic, 'Berk Jones', '.', 'k', epsilon, mu),
}

STAT_OPTIMAL = 'optimal'
STAT_HC2004 = 'hc2004'
STAT_HC2008 = 'hc2008'
STAT_CKSPLUS = 'cksplus'
STAT_MAX = 'max(x)'
STAT_SUM = 'sum(x)'
STAT_BJ = 'bj'
ALL_STATS = [STAT_OPTIMAL, STAT_SUM, STAT_MAX, STAT_HC2004, STAT_HC2008, STAT_CKSPLUS, STAT_BJ]

class StdNormalGenerator(object):
    def __init__(self, n):
        self.n = n

    def next(self):
        return numpy.random.normal(0,1,self.n)

class RareWeakGenerator(object):
    def __init__(self, n, epsilon, mu):
        self.n = n
        self.epsilon = epsilon
        self.mu = mu

    def next(self):
        chooser = (numpy.random.uniform(size=self.n) < self.epsilon)
        return (~chooser)*numpy.random.normal(0, 1, size=self.n) + chooser*numpy.random.normal(self.mu, 1, size=self.n)

def samples_to_sorted_stdnormal_pvalues(data):
    return sorted_p_values(data, stdnormal_p_value_one_sided)

def precalc_rareweak_roc_curve_n10000(reps):
    N = 10000
    EPSILON = 0.01
    MU = 1.5
    H0_generator = StdNormalGenerator(N)
    H1_generator = RareWeakGenerator(N, EPSILON, MU)
    stat_funcs = [STATISTIC_DICT[name](EPSILON, MU) for name in ALL_STATS]
    rocgen = roc.ROCGeneratorMulti(stat_funcs, ALL_STATS, H0_generator, H1_generator, samples_to_sorted_stdnormal_pvalues)
    rocgen.generate(reps)
    save_data('precalc_rareweak_roc_curve_n10000', n=N, stats=ALL_STATS, epsilon=EPSILON, mu=MU, repetitions=reps, results=rocgen.roc_curves)

def precalc_rareweak_roc_curve_2_n10000(reps):
    N = 10000
    EPSILON = 0.001
    MU = 3.0 
    H0_generator = StdNormalGenerator(N)
    H1_generator = RareWeakGenerator(N, EPSILON, MU)
    stat_funcs = [STATISTIC_DICT[name](EPSILON, MU) for name in ALL_STATS]
    rocgen = roc.ROCGeneratorMulti(stat_funcs, ALL_STATS, H0_generator, H1_generator, samples_to_sorted_stdnormal_pvalues)
    rocgen.generate(reps)
    save_data('precalc_rareweak_roc_curve_2_n10000', n=N, stats=ALL_STATS, epsilon=EPSILON, mu=MU, repetitions=reps, results=rocgen.roc_curves)

def plot_rareweak_roc_curves(pickle_name):
    data = load_data(pickle_name)
    roc_cksplus = data.results[data.stats.index('cksplus')]
    roc_cksplus._testname = '$\mbox{CKS}^+$'

    roc_sum = data.results[data.stats.index('sum(x)')]
    roc_sum._testname = '$\sum x_i$'

    roc_max = data.results[data.stats.index('max(x)')]
    roc_max._testname = '$\max x_i$'

    roc_hc2004 = data.results[data.stats.index('hc2004')]
    roc_hc2004._testname = '$\mbox{HC}^{2004}$'

    roc_optimal = data.results[data.stats.index('optimal')]
    roc_optimal._testname = 'optimal'

    roc_optimal.plot('--','k')
    roc_cksplus.plot('D', 'b')
    roc_hc2004.plot('*', 'r')
    roc_sum.plot('<', 'g')
    roc_max.plot('x', 'c')

@save_figure_for_publication_bigfonts('rare_weak_roc_curve_n10000')
def figure_rareweak_ROC_curve_n10000():
    plot_rareweak_roc_curves('precalc_rareweak_roc_curve_n10000')

@save_figure_for_publication_bigfonts('rare_weak_roc_curve_2_n10000')
def figure_rareweak_ROC_curve_2_n10000():
    plot_rareweak_roc_curves('precalc_rareweak_roc_curve_2_n10000')

def calc_misdetection_rate_sweep_single((stat_names, n, epsilon, mu, reps)):
    assert 0 <= epsilon <= RARE_WEAK_MAX_EPSILON
    stat_funcs = []
    H0_generator = StdNormalGenerator(n)
    H1_generator = RareWeakGenerator(n, epsilon, mu)
    stat_funcs = [STATISTIC_DICT[name](epsilon, mu) for name in stat_names]
    import roc
    rocgen = roc.ROCGeneratorMulti(stat_funcs, stat_names, H0_generator, H1_generator, samples_to_sorted_stdnormal_pvalues)
    rocgen.generate(reps)
    #return [roc.get_auc() for roc in rocgen.roc_curves]
    return [1.0 - roc.get_power_at_alpha(ALPHA_FOR_RAREWEAK_SWEEP) for roc in rocgen.roc_curves]

def calc_misdetection_rate_sweep_parallelized(stat_names, n, epsilon_range, mu_range, reps):
    start_time = time.time()

    print 'Statistics:', str(stat_names)
    print 'n:', n, 'r_steps:', 'reps:', reps
    print 'epsilon_range:', str(epsilon_range)
    print 'mu_range:', str(mu_range)

    epsilon_range_middlepoints = (epsilon_range[1:] + epsilon_range[:-1])/2.0
    mu_range_middlepoints = (mu_range[1:] + mu_range[:-1])/2.0

    params = [(stat_names, n, epsilon, mu, reps) for epsilon in epsilon_range_middlepoints for mu in mu_range_middlepoints]
    results = parallel_map(calc_misdetection_rate_sweep_single, params)

    print 'Finished in %d seconds.' % int(time.time() - start_time)

    return [results[len(mu_range_middlepoints)*i:len(mu_range_middlepoints)*(i+1)] for i in xrange(len(epsilon_range_middlepoints))]
    
def precalc_rareweak_misdetection_sweep_n1000_highres(reps):
    N = 1000
    EPSILON_RANGE = arange(0,0.1,0.0025)
    MU_RANGE = arange(0,4.0,0.1)
    res = calc_misdetection_rate_sweep_parallelized(ALL_STATS, N, EPSILON_RANGE, MU_RANGE, reps)
    save_data('precalc_rareweak_misdetection_sweep_n1000_highres', n=N, stats=ALL_STATS, epsilon_range=EPSILON_RANGE, mu_range=MU_RANGE, repetitions=reps, results=res)

def precalc_rareweak_misdetection_sweep_n10000_highres(reps):
    N = 10000
    EPSILON_RANGE = arange(0,0.05,0.00125)
    MU_RANGE = arange(0,4.0,0.1)
    res = calc_misdetection_rate_sweep_parallelized(ALL_STATS, N, EPSILON_RANGE, MU_RANGE, reps)
    save_data('precalc_rareweak_misdetection_sweep_n10000_highres', n=N, stats=ALL_STATS, epsilon_range=EPSILON_RANGE, mu_range=MU_RANGE, repetitions=reps, results=res)
    
def pcolor_with_ranges(x_range, y_range, data, colormap = None):
    extended_ranges = tuple(list(rng) + [rng[-1] + (rng[-1] - rng[-2])] for rng in (x_range, y_range))
    (Xs, Ys) = meshgrid(*extended_ranges)
    xlim(0, extended_ranges[0][-1])
    ylim(0, extended_ranges[1][-1])
    pcolor(Xs, Ys, data, cmap = colormap)

def figures_auc_sweep(stat_names, n, epsilon_range, mu_range, reps, res, best_algorithm_annotations = None):
    start_time = time.time()

    #for (i,statname) in enumerate(stat_names):
    #    pylab.figure()
    #    pcolor_with_ranges(mu_range, epsilon_range, array([[res_epsilon_r[i] for res_epsilon_r in res_epsilon] for res_epsilon in res]))
    #    pylab.colorbar()
    #    pylab.title(statname)
    #    pylab.xlabel('$\mu$')
    #    pylab.ylabel('$\epsilon$')

    arrargmax = array([[numpy.argmax(res_epsilon_r) for res_epsilon_r in res_epsilon] for res_epsilon in res])
    arrmax = array([[numpy.max(res_epsilon_r) for res_epsilon_r in res_epsilon] for res_epsilon in res])
    arrmin = array([[numpy.min(res_epsilon_r) for res_epsilon_r in res_epsilon] for res_epsilon in res])
    #return arrargmax, arrmax
    #cm = ListedColormap([[0,0,0], [1,1,1], [0,0,1], [0,1,0], [0,1,1], [1,0,0], [1,0,1], [1,1,0]])
    #                                      STAT_SUM, STAT_MAX, STAT_HC2004, STAT_HC2008, STAT_CKSPLUS]
    cm = ListedColormap([[0,0,0], [1,1,1], [1,0,1],  [0,1,0],  [1,1,0],     [1,0,0],     [0,1,1],     [0,0,1]])
    MIN_VAL = 0.55
    MAX_VAL = 0.99
    interesting_range_mask = (arrmax>MIN_VAL)*(arrmin<MAX_VAL)
    #import pdb
    #pdb.set_trace()
    #output = 2+arrargmax
    #output[arrmax<MIN_VAL] = 0
    #output[arrmax>MAX_VAL] = 1
    #pcolor_with_ranges(mu_range, epsilon_range, output, cm)
    pcolor_with_ranges(mu_range, epsilon_range, (2+arrargmax)*interesting_range_mask +  (arrmin>=MAX_VAL)*1, cm)
    title('Best algorithm (n=%d)' % n)
    xlabel('$\mu$')
    ylabel('$\epsilon$')
    if best_algorithm_annotations != None:
        for (mu, epsilon, text, size, color) in best_algorithm_annotations:
            pylab.text(mu, epsilon, text, size=size, color=color)
    print 'Finished in %d seconds.' % int(time.time() - start_time)

def figures_misdetection_rate_sweep(stat_names, n, epsilon_range, mu_range, reps, res, best_algorithm_annotations = None):
    start_time = time.time()

    #for (i,statname) in enumerate(stat_names):
    #    pylab.figure()
    #    pcolor_with_ranges(mu_range, epsilon_range, array([[res_epsilon_r[i] for res_epsilon_r in res_epsilon] for res_epsilon in res]))
    #    pylab.colorbar()
    #    pylab.title(statname)
    #    pylab.xlabel('$\mu$')
    #    pylab.ylabel('$\epsilon$')

    arrargmin = array([[numpy.argmin(res_epsilon_r) for res_epsilon_r in res_epsilon] for res_epsilon in res])
    #arrmax = array([[numpy.max(res_epsilon_r) for res_epsilon_r in res_epsilon] for res_epsilon in res])
    #arrmin = array([[numpy.min(res_epsilon_r) for res_epsilon_r in res_epsilon] for res_epsilon in res])
    #return arrargmax, arrmax
    #cm = ListedColormap([[0,0,0], [1,1,1], [0,0,1], [0,1,0], [0,1,1], [1,0,0], [1,0,1], [1,1,0]])
    #                                      STAT_SUM, STAT_MAX, STAT_HC2004, STAT_HC2008, STAT_CKSPLUS]
    cm = ListedColormap([[0,0,0], [1,1,1], [1,0,1],  [0,1,0],  [1,1,0],     [1,0,0],     [0,1,1],     [0,0,1]])
    #MIN_VAL = 0.55
    #MAX_VAL = 0.99
    #interesting_range_mask = (arrmax>MIN_VAL)*(arrmin<MAX_VAL)

    #import pdb
    #pdb.set_trace()
    #output = 2+arrargmax
    #output[arrmax<MIN_VAL] = 0
    #output[arrmax>MAX_VAL] = 1
    #pcolor_with_ranges(mu_range, epsilon_range, output, cm)
    #pcolor_with_ranges(mu_range, epsilon_range, (2+arrargmax)*interesting_range_mask +  (arrmin>=MAX_VAL)*1, cm)
    pcolor_with_ranges(mu_range, epsilon_range, (2+arrargmin), cm)
    title('Best algorithm (n=%d)' % n)
    xlabel('$\mu$')
    ylabel('$\epsilon$')
    if best_algorithm_annotations != None:
        for (mu, epsilon, text, size, color) in best_algorithm_annotations:
            pylab.text(mu, epsilon, text, size=size, color=color)
    print 'Finished in %d seconds.' % int(time.time() - start_time)

def plot_sweep_for_stat_name(stats, epsilon_range, mu_range, all_stat_results, stat_name):
    print 'stat_name:', stat_name
    figure()
    stat_index = stats.index(stat_name)
    stat_res = array([[1.0-res_epsilon_r[stat_index] for res_epsilon_r in res_epsilon] for res_epsilon in all_stat_results])
    # We cut the range of epsilon and mu, since the precomputed data is done on the middle points.
    pcolor_with_ranges(mu_range[:-1], epsilon_range[:-1], stat_res)
    colorbar()
    plot_title = STATISTIC_DICT[stat_name](0,0).name
    title(plot_title)
    xlabel('$\mu$')
    ylabel('$\epsilon$')

def figure_rareweak_power_sweep_n1000():
    data = load_data('precalc_rareweak_misdetection_sweep_n1000')
    for statname in ALL_STATS:
        plot_sweep_for_stat_name(data.stats, data.epsilon_range, data.mu_range, data.results, statname)
        save_figure('rare_weak_power_sweep_%s_n1000' % (statname,))

def figure_rareweak_power_sweep_n10000():
    data = load_data('precalc_rareweak_misdetection_sweep_n10000')
    for statname in ALL_STATS:
        plot_sweep_for_stat_name(data.stats, data.epsilon_range, data.mu_range, data.results, statname)
        save_figure('rare_weak_power_sweep_%s_n10000' % (statname,))

def epsilon_to_beta(epsilon, n):
    # epsilon = 1/(n**beta)
    beta = -log(epsilon)/log(n)
    return beta

def rho_star(beta):
    if beta <= 0.5:
        return 0
    elif beta <= 0.75:
        return beta-0.5
    elif beta < 1:
        return (1-(1-beta)**0.5)**2
    else:
        return numpy.inf

def smallest_detectable_mu(epsilon, n):
    beta = epsilon_to_beta(epsilon, n)
    r_star = rho_star(beta)
    mu_star = sqrt(2*r_star*log(n))
    return mu_star

def plot_rw_best_algorithm(pickle_name, min_better_factor, min_much_better_factor, misdetection_rate_lower_cutoff, misdetection_rate_upper_cutoff):
    data = load_data(pickle_name)
    sweep = array(data.results)
    stat_sum = sweep[:,:,data.stats.index('sum(x)')]
    stat_max = sweep[:,:,data.stats.index('max(x)')]
    stat_hc2004 = sweep[:,:,data.stats.index('hc2004')]
    stat_cksplus = sweep[:,:,data.stats.index('cksplus')]
    stat_all = dstack((stat_sum, stat_max, stat_hc2004, stat_cksplus))
    stat_all.sort()
    stat_best = stat_all[:,:,0]
    stat_second_best = stat_all[:,:,1]

    mask = (stat_best>misdetection_rate_lower_cutoff)&(stat_best<misdetection_rate_upper_cutoff)

    stat_max_better = (stat_max<stat_second_best)*(min_better_factor < stat_second_best/(stat_max+0.001))
    stat_sum_better = (stat_sum<stat_second_best)*(min_better_factor < stat_second_best/(stat_sum+0.001))
    stat_hc2004_better = (stat_hc2004<stat_second_best)*(min_better_factor < stat_second_best/(stat_hc2004+0.001))
    stat_cks_better = (stat_cksplus<stat_second_best)*(min_better_factor < stat_second_best/(stat_cksplus+0.001))

    stat_max_much_better = (stat_max<stat_second_best)*(min_much_better_factor < stat_second_best/(stat_max+0.001))
    stat_sum_much_better = (stat_sum<stat_second_best)*(min_much_better_factor < stat_second_best/(stat_sum+0.001))
    stat_hc2004_much_better = (stat_hc2004<stat_second_best)*(min_much_better_factor < stat_second_best/(stat_hc2004+0.001))
    stat_cks_much_better = (stat_cksplus<stat_second_best)*(min_much_better_factor < stat_second_best/(stat_cksplus+0.001))

    cm = ListedColormap([[1.0]*3, [0.80]*3,
                         [0,1,1], [0.3, 0.7, 0.3], [1, 0.5, 0.5], [0.5, 0.5, 1],
                         [0,1,1], [0, 0.6, 0],     [1, 0, 0],     [0, 0, 1],
                         ])
                #                    Out       Band     Max       Sum      HC2004   CKS
    plot_data = mask*(1 + 1*stat_max_better + 2*stat_sum_better + 3*stat_hc2004_better + 4*stat_cks_better
                      + 4*stat_max_much_better + 4*stat_sum_much_better + 4*stat_hc2004_much_better + 4*stat_cks_much_better)
    pcolor_with_ranges(data.mu_range[:-1], data.epsilon_range[:-1], plot_data, cm)

    # Plot asymptotic detectability curve
    # Donoho&Jin 2004, Eq. (1.6)
    epsilons = arange(0.00001, data.n**(-0.5), 0.00001)
    minimal_mu_values = [smallest_detectable_mu(epsilon, data.n) for epsilon in epsilons]
    plot(minimal_mu_values, epsilons, 'k--')

    xlabel('$\mu$')
    ylabel('$\epsilon$')
    grid(True, which='minor')

@save_figure_for_publication_bigfonts('rare_weak_misdetection_leader_n1000_highres')
def figure_rareweak_misdetection_leader_n1000_highres():
    plot_rw_best_algorithm('precalc_rareweak_misdetection_sweep_n1000_highres', min_better_factor = 1.1, min_much_better_factor = 1.5, misdetection_rate_lower_cutoff = 0.001, misdetection_rate_upper_cutoff = 0.8)

    text(0.4, 0.085, '$\sum x_i$', size=30, color='k')
    text(3.1, 0.006, 'HC', size=24, color='k')
    text(1.5, 0.035, '$\mbox{CKS}^+$', size=30, color='w')
    text(0.02, 0.001, r'misdetection $> 80\%$', size=24, color='k')
    text(2.0, 0.07, r'misdetection $< 0.1\%$', size=24, color='k')
    g = gca()
    g.set_xticks(arange(0,4.0,0.5))
    xticks()
    g.set_yticks(arange(0,0.1,0.01))
    yticks()
    grid(True)

@save_figure_for_publication_bigfonts('rare_weak_misdetection_leader_n10000_highres')
def figure_rareweak_misdetection_leader_n10000_highres():
    plot_rw_best_algorithm('precalc_rareweak_misdetection_sweep_n10000_highres', min_better_factor = 1.1, min_much_better_factor = 1.5, misdetection_rate_lower_cutoff = 0.001, misdetection_rate_upper_cutoff = 0.8)
    text(0.4, 0.033, '$\sum x_i$', size=30, color='k')
    text(3.1, 0.0001, 'HC', size=24, color='k')
    text(1.3, 0.01, '$\mbox{CKS}^+$', size=30, color='w')
    text(0.02, 0.001, r'misdetection $> 80\%$', size=24, color='k')
    text(2.0, 0.025, r'misdetection $< 0.1\%$', size=24, color='k')
    g = gca()
    g.set_xticks(arange(0,4.0,0.5))
    xticks()
    g.set_yticks(arange(0,0.05,0.01))
    yticks()
    grid(True)

###############################################################################
###############################################################################
###############################################################################

def precalc_everything(reps):
    raise "Do you really want to do this?"
    print 'Normal scaling, Kolmogorov-Smirnov vs. Anderson-Darling vs. CKS'
    precalc_normal_scaling_KS_vs_AD_vs_CKS(reps)
    print 'Normal displacement, Kolmogorov-Smirnov vs. Anderson-Darling vs. CKS'
    precalc_normal_displacement_KS_vs_AD_vs_CKS(reps)

    print 'Powerlaw detection. H0: Powerlaw    H1: Lognormal'
    precalc_powerlaw_vs_lognormal_detection(reps*5)
    print 'Powerlaw detection. H0: Powerlaw    H1: Exponential'
    precalc_powerlaw_vs_exponential_detection(reps*5)

    print 'Rare-weak ROC curve (epsilon=0.01, mu=1.5): optimal vs. CKS, vs. HC2004 vs. sum vs. max'
    precalc_rareweak_roc_curve_n10000(reps)
    print 'Rare-weak ROC curve (epsilon=0.001, mu=3): optimal vs. CKS, vs. HC2004 vs. sum vs. max'
    precalc_rareweak_roc_curve_2_n10000(reps)

    print 'Rare-weak detection power at alpha=%f for various epsilon and mu values (n=1000)' % ALPHA_FOR_RAREWEAK_SWEEP
    precalc_rareweak_misdetection_sweep_n1000(reps/10)
    print 'Rare-weak detection power at alpha=%f for various epsilon and mu values (n=10000)' % ALPHA_FOR_RAREWEAK_SWEEP
    precalc_rareweak_misdetection_sweep_n10000(reps/10)

def render_all_figures_from_precalcs():
    figure_normal_displacement_KS_vs_AD_vs_CKS()
    figure_normal_scaling_KS_vs_AD_vs_CKS()
    figure_powerlaw_vs_exponential_vs_lognormal_pdf()
    figure_powerlaw_vs_exponential_detection_power()
    figure_powerlaw_vs_lognormal_detection_power()
    #figure_rareweak_misdetection_leader_n1000()
    #figure_rareweak_misdetection_leader_n10000()
    figure_rareweak_misdetection_leader_n1000_highres()
    figure_rareweak_misdetection_leader_n10000_highres()
    figure_rareweak_ROC_curve_n10000()
    figure_rareweak_ROC_curve_2_n10000()

def produce_all_figures_from_scratch():
    REPS = 100000
    print '=== Performing all precalculations (REPS: %d) =================' % REPS
    precalc_everything(REPS)
    print '=== Producing all figures =========================================='
    render_all_figures_from_precalcs()
