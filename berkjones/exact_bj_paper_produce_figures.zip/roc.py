from numpy import array, arange
from itertools import islice
import speed

def _integrate(xs, ys):
    y_averages = (ys[1:] + ys[:-1]) / 2.0
    x_spans = xs[1:] - xs[:-1]
    return (y_averages * x_spans).sum()

class ROC(object):
    def __init__(self, testname, H0_scores, H1_scores):
        self._testname = testname
        self._H0_scores = H0_scores
        self._H1_scores = H1_scores

    def get_roc(self):
        decorated_points = [(score, 0) for score in self._H0_scores] + [(score, 1) for score in self._H1_scores]
        sorted_points = sorted(decorated_points, reverse = True)
        labels = array([-1] + [label for (score, label) in sorted_points])
        false_positive_rate = (labels == 0).cumsum() / float(len(self._H0_scores))
        detection_rate      = (labels == 1).cumsum() / float(len(self._H1_scores))
        return (false_positive_rate, detection_rate)

    def get_power_at_alpha(self, alpha):
        assert 0.0 <= alpha <= 1.0
        (false_positive_rate, detection_rate) = self.get_roc()
        index = false_positive_rate.searchsorted(alpha)
        return detection_rate[index]

    def get_auc(self):
        (false_positive_rate, detection_rate) = self.get_roc()
        return _integrate(false_positive_rate, detection_rate)

    def plot(self, marker = '.', color = 'b'):
        import pylab
        (xs, ys) = self.get_roc()
        #pylab.plot([0.0,1.0], [0.0,1.0], 'r--')
        pylab.plot(xs, ys, '-'+color)
        pylab.plot([xs[int(len(xs)*i/20.0)] for i in range(20)],
                   [ys[int(len(ys)*i/20.0)] for i in range(20)],
                   color+marker, label = self._testname)
        pylab.xlabel('False positive rate')
        pylab.ylabel('Power')
        pylab.legend(loc = 'lower right')
        pylab.xticks(arange(0, 1.05, 0.1))
        pylab.yticks(arange(0, 1.05, 0.1))
        pylab.grid(True)

    def save(self, filename):
        import cPickle
        with file(filename, 'wb') as f:
            data = ('ROC', self._testname, self._H0_scores, self._H1_scores)
            cPickle.dump(data, f, 2)

    @classmethod
    def load(cls, filename):
        import cPickle
        with file(filename, 'rb') as f:
            data = cPickle.load(f)
            assert data[0] == 'ROC'
            (_, testname, H0_scores, H1_scores) = data
        return cls(testname, H0_scores, H1_scores)

class ROCGenerator(ROC):
    def __init__(self, testfunc, testname, H0_generator, H1_generator):
        self._testfunc = testfunc
        self._testname = testname
        self._H0_gen = H0_generator
        self._H1_gen = H1_generator
        self._H0_scores = []
        self._H1_scores = []

    def generate(self, n_iterations):
        self._H0_scores.extend(self._testfunc(x) for x in islice(self._H0_gen, n_iterations))
        self._H1_scores.extend(self._testfunc(x) for x in islice(self._H1_gen, n_iterations))

class ROCGeneratorMulti(object):
    """ROCGeneratorMulti(testfunc_list, testname_list, H0_generator, H1_generator)

    Compute ROC curves for multiple test statistics in the context of deciding between the two hypotheses H0 and H1.
    testfunc_list - list of test statistics. Each test statistic is able to take an instance of H0/H1 and produce a number, where higher numbers imply H1.
    testname_list - list of names matching the test statistics in testfunc_list.
    H0_generator - generator for instances of the null hypothesis
    H1_generator - generator for instances of the alternative hypothesis.

    Usage:
    0. Run generate(n_iterations) with some high number of n_iterations.
    1. Examine roc_curves[i] to obtain an ROC object, representing the ROC curve of the i-th test.
    """
    def __init__(self, testfunc_list, testname_list, H0_generator, H1_generator, data_preprocessor = None):
        assert len(testfunc_list) == len(testname_list)
        n_tests = len(testname_list)
        self._testfunc_list = testfunc_list
        self._H0_gen = H0_generator
        self._H1_gen = H1_generator
        self.roc_curves = [ROC(testname, [], []) for testname in xrange(n_tests)]
        self.data_preprocessor = data_preprocessor

    def generate(self, n_iterations):
        for i in speed.progress(xrange(n_iterations)):
            sample = self._H0_gen.next()
            if self.data_preprocessor != None:
                processed_data = self.data_preprocessor(sample)
            for (roc, testfunc) in zip(self.roc_curves, self._testfunc_list):
                if self.data_preprocessor != None:
                    roc._H0_scores.append(testfunc(sample, processed_data = processed_data))
                else:
                    roc._H0_scores.append(testfunc(sample))


        for i in speed.progress(xrange(n_iterations)):
            sample = self._H1_gen.next()
            if self.data_preprocessor != None:
                processed_data = self.data_preprocessor(sample)
            for (roc, testfunc) in zip(self.roc_curves, self._testfunc_list):
                if self.data_preprocessor != None:
                    roc._H1_scores.append(testfunc(sample, processed_data = processed_data))
                else:
                    roc._H1_scores.append(testfunc(sample))
