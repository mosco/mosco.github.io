This code reproduces the figures from the paper "The Calibrated Kolmogorov Smirnov test".
Preprint: http://arxiv.org/abs/1311.3190

To run this code you must install Python 2.7, Numpy, Scipy and Matplotlib.Then open your python interpreter and run:
    execfile("cks_paper.py")
    produce_all_figures_from_scratch(REPS = 1000)

Note: the final figures in the paper were run with reps=100,000 and took weeks to finish.

Please send any questions and bug reports to: moscovich -at- gmail -dot- com

Amit Moscovich Eiger, Weizmann Institute of Science, 12/2013.
