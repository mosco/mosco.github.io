from numpy import arange, sort, asarray
from scipy.special import betainc

def _uniform_order_statistic_cdf(i, n, t):
    """Calculates the probability that the i-th smallest element (Note! when counting from 0) out of n uniform[0,1] variables is smaller than t. This function works for scalars as well as numpy arrays"""
    # betainc(k, n-k+1, t) = gamma(n+1) / (gamma(k)*gamma(n-k+1)) * integral
    # = (n! / (k-1)!(n-k)!) * integral(x**(k-1) (1-x)**(n-k), t=0..t)
    #
    # We want to calculate (n-1)! / ((k-1)!(n-k)!) * integral..
    return betainc(i+1, n-i, t)

def cks(uniform01_samples):
    """cks(uniform01_samples) -> CKS score
    Compute the two sided CKS test statistic for a list of samples.
    uniform01_samples - samples in the range [0,1].

    To test goodness of fit to an arbitrary cumulative distribution function F, apply the distribution function on your samples and then use cks().
    e.g. to test if the samples fit a standard gaussian use cks(
    To test goodness-of-fit to a 
    """
    return cks_fast(sort(uniform01_samples))

def cks_fast(sorted_uniform01_samples):
    assert 0 <= sorted_uniform01_samples[0] <= sorted_uniform01_samples[-1] <= 1
    n = len(sorted_uniform01_samples)
    p_values = _uniform_order_statistic_cdf(arange(n), n, asarray(sorted_uniform01_samples))
    return min(p_values.min(), 1.0-p_values.max())

def cks_plus(uniform01_samples, alpha = 1.0):
    return cks_plus_fast(sort(uniform01_samples), alpha)

def cks_plus_fast(sorted_uniform01_samples, alpha):
    assert 0 <= alpha <= 1
    assert 0 <= sorted_uniform01_samples[0] <= sorted_uniform01_samples[-1] <= 1
    N = len(sorted_uniform01_samples)
    n = int(N*alpha)
    p_values = _uniform_order_statistic_cdf(arange(n), N, asarray(sorted_uniform01_samples[:n]))
    return p_values.min()

def cks_minus(uniform01_samples):
    return cks_minus_fast(sort(uniform01_samples))

def cks_minus_fast(sorted_uniform01_samples):
    assert 0 <= sorted_uniform01_samples[0] <= sorted_uniform01_samples[-1] <= 1
    n = len(sorted_uniform01_samples)
    p_values = _uniform_order_statistic_cdf(arange(n), n, asarray(sorted_uniform01_samples))
    return 1.0-p_values.max()
