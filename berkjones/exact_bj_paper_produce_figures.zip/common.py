#import speed
import os
import numpy
import pylab
import matplotlib
from matplotlib import rcParams, rcdefaults
import cPickle
import bisect
from functools import wraps
import errno
from dirs import CKS_DIR

FIGURES_PATH = os.path.join(CKS_DIR, 'figures')
PICKLES_PATH = os.path.join(CKS_DIR, 'pickles')

def set_matplotlib_params_bigfonts():
    print 'Setting matplotlib parameters.'
    rcdefaults()
    rcParams.update({'font.size': 26})
    rcParams.update({'lines.markersize':16})
    rcParams.update({'lines.linewidth':2.0})
    rcParams.update({'xtick.major.pad':10})
    rcParams.update({'xtick.minor.pad':10})
    rcParams.update({'ytick.major.pad':10})
    rcParams.update({'ytick.minor.pad':10})
    rcParams.update({'xtick.labelsize':'medium'})
    rcParams.update({'ytick.labelsize':'medium'})
    #rcParams.update({'figure.subplot.bottom': 0.12})
    rcParams.update({'legend.fancybox': True})
    rcParams.update({'figure.autolayout': True})
    rcParams.update({'text.usetex': True})

def set_matplotlib_params_smallfonts():
    print 'Setting matplotlib parameters.'
    rcdefaults()
    rcParams.update({'font.size': 24})
    rcParams.update({'lines.markersize':10})
    rcParams.update({'xtick.major.pad':10})
    rcParams.update({'xtick.minor.pad':10})
    rcParams.update({'ytick.major.pad':10})
    rcParams.update({'ytick.minor.pad':10})
    rcParams.update({'xtick.labelsize':'medium'})
    rcParams.update({'ytick.labelsize':'medium'})
    #rcParams.update({'figure.subplot.bottom': 0.12})
    rcParams.update({'legend.fancybox': True})
    rcParams.update({'figure.autolayout': True})
    rcParams.update({'text.usetex': True})

@numpy.vectorize
def uniform_01_cdf(x):
    "Cumulative Distribution Function of the Uniform[0,1] distribution"
    if x <= 0:
        return 0.0
    elif x >= 1:
        return 1
    else:
        return x

class PValueEstimator(object):
    def __init__(self, n, reps):
        self.values = sorted([self.uniform_01_fit_test_function(numpy.sort(numpy.random.random(n))) for i in xrange(reps)])

    def uniform_01_fit_test_function(self, samples):
        """uniform_01_fit_test_function:[0,1]^n => R
        Is some goodness of fit statistic for uniform[0,1] distributions.

        IMPORTANT: higher values must mean worse fit!
        """
        raise NotImplementedError

    def pvalue(self, result):
        n = len(self.values)
        return (n - bisect.bisect_left(self.values, result)) / float(n)

    def get_significance_bound(self, alpha):
        index = int(len(self.values)*(1-alpha))
        return self.values[index]

def mkdir_recursively(dirname):
    try:
        os.makedirs(dirname)
    except OSError as exc: # Python >2.5
        if exc.errno == errno.EEXIST and os.path.isdir(dirname):
            pass
        else:
            raise

def pickled_name(name):
    return os.path.join(PICKLES_PATH, name) + '.pickle'

def get_calling_func_source():
    import inspect, sys
    return inspect.getsource(sys._getframe().f_back.f_back.f_code)

def save_data(name, **kwargs):
    mkdir_recursively(PICKLES_PATH)
    metadata = get_calling_func_source()
    picklename = pickled_name(name)
    with file(picklename, 'wb') as f:
        print 'Saving to', picklename
        print 'Fields:', ', '.join(sorted(kwargs.keys()))
        cPickle.dump((metadata, kwargs), f, 2)

class StructFromDict:
    def __init__(self, d): 
        self.__dict__.update(d)

def load_data(name):
    picklename = pickled_name(name)
    print 'Loading', picklename
    with file(picklename, 'rb') as f:
        (metadata, data_dict) = cPickle.load(f)
    return StructFromDict(data_dict)

def touch(filename):
    with file(filename, 'a'):
        os.utime(filename, None)

def save_figure(filename):
    pylab.gca().title.set_y(1.02) # Pad title
    mkdir_recursively(FIGURES_PATH)
    assert not filename.endswith('.png')
    assert not filename.endswith('.eps')
    assert not filename.endswith('.pdf')
    # Note, you need some version of GhostScript to produce these figures.
    path = os.path.join(FIGURES_PATH, filename.replace('.','_').replace('(','_').replace(')','_').lower()) + '.eps'
    print 'Saving to', path
    pylab.savefig(path, dpi=300, bbox_inches='tight')
    pylab.close()
    # For some reason, the time of the saved files appears incorrect.
    touch(path)
    
def save_figure_for_publication_bigfonts(name):
    def save_figures_to_name_decorator(func):
        @wraps(func)
        def f():
            pylab.close()
            set_matplotlib_params_bigfonts()
            func()
            save_figure(name)
            pylab.close()
        return f
    return save_figures_to_name_decorator

def save_figure_for_publication_smallfonts(name):
    def save_figures_to_name_decorator(func):
        @wraps(func)
        def f():
            pylab.close()
            set_matplotlib_params_smallfonts()
            func()
            save_figure(name)
            pylab.close()
        return f
    return save_figures_to_name_decorator

