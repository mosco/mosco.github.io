import numpy
from numpy import arange, log, mean
from bisect import bisect_left
#import speed
import common

def _log_LR(ith_order_statistic, n, i):
    if ith_uniform_order_statistic >= i/float(n):
        return 0
    else:
        return 

def _logLRn(n, t, Fn_at_t):
    #print '_logLRn(%d, %f, %f)' % (n, t, Fn_at_t)
    if (t >= Fn_at_t) or (Fn_at_t >= 1.0):
        return 0
    return n*Fn_at_t*log(Fn_at_t/t) + n*(1-Fn_at_t)*log((1-Fn_at_t)/(1-t))

def _LRn(n, t, Fn_at_t):
    #print '_logLRn(%d, %f, %f)' % (n, t, Fn_at_t)
    if t >= Fn_at_t:
        return 1.0
    return ((Fn_at_t/t)**(n*Fn_at_t))*((1-Fn_at_t)/(1-t))**(n*(1-Fn_at_t))

def bjtest_slow(samples, alpha = 1.0):
    assert 0 <= alpha <= 1
    n = len(samples)
    sorted_samples = sorted(samples)
    logLRn_values = [_logLRn(float(n), t, (i+1)/float(n)) for (i, t) in enumerate(sorted_samples)]
    print 'logLRn_values:', logLRn_values
    return max(logLRn_values[:int(n*alpha)])

def bjtest(samples, alpha = 1.0):
    """Calculates the Berk-Jones test between a collection of samples and a known distribution (given by its CDF)

    """
    #print 'blah:',samples
    assert 0 <= alpha <= 1
    N = len(samples)
    n = int(N*alpha)

    sorted_p_i = numpy.sort(samples)[:n]
    assert sorted_p_i[0] >= 0
    assert sorted_p_i[-1] <= 1
    
    indices = 1 + arange(n)
    support = (sorted_p_i < indices/float(N))
    logLRi = support*(indices * log(indices / (N*sorted_p_i)) + (N-indices)*log((1.0 - indices/float(N))/(1-sorted_p_i)))
    #if (logLRi == numpy.nan).sum() > 0:
	#	print logLRi
    return numpy.max(logLRi[logLRi != numpy.nan])

class BJPValueEstimator(common.PValueEstimator):
    def uniform_01_fit_test_function(self, samples):
        return bjtest(samples)

def get_lower_bound(log_value, i, n):
    start = 0.000000000000000000000000001
    end = (i+1)/float(n)
    value = numpy.exp(log_value)
    prev_range = (None, None)
    while (start, end) != prev_range:
        #print (start, end)
        mid = (end+start)/2.0
        result = _LRn(n, mid, (i+1)/float(n)) 
        prev_range = (start, end)
        if result > value:
            (start, end) = (mid, end)
        else:
            (start, end) = (start, mid)
    return mid

