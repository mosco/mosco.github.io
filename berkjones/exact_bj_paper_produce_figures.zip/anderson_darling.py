from numpy import arange, asarray, argmax, sort, log, dot
import common

def anderson_darling_test(samples, F = common.uniform_01_cdf):
    u = sort(F(asarray(samples)))
    assert u[0] >= 0
    assert u[-1] <= 1
    n = float(len(u))

    W2 = -n-(1/n)*dot(2*arange(n)+1, log(u) + log(1-u[::-1]))

    return W2

